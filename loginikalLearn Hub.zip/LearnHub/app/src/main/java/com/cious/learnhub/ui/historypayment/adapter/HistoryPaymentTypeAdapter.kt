package com.cious.learnhub.ui.historypayment.adapter

enum class HistoryPaymentTypeAdapter {
    PAID, NOT_PAID

}