package com.cious.learnhub.ui.profile.changepassword

import androidx.lifecycle.ViewModel

class ChangePasswordViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}