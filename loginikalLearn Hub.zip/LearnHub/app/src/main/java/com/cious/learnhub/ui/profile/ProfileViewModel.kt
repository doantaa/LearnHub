package com.cious.learnhub.ui.profile

import androidx.lifecycle.ViewModel

class ProfileViewModel : ViewModel() {

}