package com.cious.learnhub.ui.myclass

import androidx.lifecycle.ViewModel

class MyClassViewModel : ViewModel() {

}