package com.cious.learnhub.core

interface ViewHolderBinder<T> {
    fun bind(item: T)
}
