package com.cious.learnhub.ui.course

import androidx.lifecycle.ViewModel

class CourseViewModel : ViewModel() {

}