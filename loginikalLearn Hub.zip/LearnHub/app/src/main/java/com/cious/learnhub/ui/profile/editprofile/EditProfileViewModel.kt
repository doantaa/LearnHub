package com.cious.learnhub.ui.profile.editprofile

import androidx.lifecycle.ViewModel

class EditProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}